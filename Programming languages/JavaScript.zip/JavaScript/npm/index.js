const posts = [
	{title: "Post 1", boyd: "This is the first post."},
	{title: "Post 2", boyd: "This is the second post."}
];

function getPost(){
	setTimeout(()=>
	{		
		let output = '';
		posts.forEach((post, index)=>
		{
			output += `<li>${post.title}</li>`;
		});
		document.body.innerHTML = output;
	}, 1000); //this would be 1 sec pf delay
}

function createPost(post){
	return new Promise((resolve, reject)=>{
		setTimeout(()=>{
			posts.push(post);
			const error = false;
			if(!error){
				resolve();
			}else{
				reject("Something went wrong!");
			}
		}, 2000);
	})
}

createPost({title:"Post 3", body:"This is post three"})
.then(getPost())